s = "i_love_programming_in_python_and_i_will_alzways_program"

for x in s:
    if s.count(x) < 2:
        print(x)
