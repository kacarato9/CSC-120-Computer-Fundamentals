SCORES = [40,91,85,15]
for i in range(len(SCORES)):
        for x in range(i+1, len(SCORES)):
            print(SCORES[i], ",", SCORES[x])





